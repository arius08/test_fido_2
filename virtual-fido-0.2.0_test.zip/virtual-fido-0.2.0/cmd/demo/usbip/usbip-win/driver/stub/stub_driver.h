#pragma once

#include <ntddk.h>

#define USBIP_STUB_POOL_TAG	(ULONG)'bUts'