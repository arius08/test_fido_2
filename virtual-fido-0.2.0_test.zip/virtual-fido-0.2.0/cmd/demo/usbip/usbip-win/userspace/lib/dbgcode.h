#pragma

extern const char *
dbg_opcode_status(int status);

extern const char *
dbg_errcode(int err);
